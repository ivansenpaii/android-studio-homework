package com.example.toastivankotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun showToast1(view: View) {
        val toast = Toast.makeText(applicationContext, "", Toast.LENGTH_LONG)
        toast.setGravity(Gravity.CENTER, 0, 0)
        // создаем новый ImageView
        val imageView = ImageView(applicationContext)
        imageView.setImageResource(R.drawable.uganda)

// создаем новый TextView для отображения текста
        val textView = TextView(applicationContext)
        textView.text = "Kotlin топ, а а php класс!!!"
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 36F)

// создаем новый LinearLayout и добавляем туда ImageView и TextView
        val linearLayout = LinearLayout(applicationContext)
        linearLayout.orientation = LinearLayout.VERTICAL
        linearLayout.addView(imageView)
        linearLayout.addView(textView)

// установка макета для LinearLayout
        val layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        linearLayout.layoutParams = layoutParams

// установка LinearLayout в качестве представления для Toast
        toast.view = linearLayout
        toast.show()
    }
}
