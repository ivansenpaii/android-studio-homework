package com.example.toastivan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //TODO Метод для создание Тоста
    public void showToast1(View view) {
        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);

        // создаем новый ImageView
        ImageView imageView = new ImageView(getApplicationContext());
        imageView.setImageResource(R.drawable.image);

        // создаем новый TextView для отображения текста
        TextView textView = new TextView(getApplicationContext());
        textView.setText("Java Учи, а лучше Go");
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 36);

        // создаем новый LinearLayout и добавляем туда ImageView и TextView
        LinearLayout linearLayout = new LinearLayout(getApplicationContext());
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.addView(imageView);
        linearLayout.addView(textView);

        // установка макета для LinearLayout
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setLayoutParams(layoutParams);

        // установка LinearLayout в качестве представления для Toast
        toast.setView(linearLayout);
        toast.show();
    }

    //TODO Метод для создание Тоста из xml
    public void showToast2(View view) {
        Toast notification = new Toast(getApplicationContext());

        // Задаем продолжительность отображения уведомления
        notification.setDuration(Toast.LENGTH_LONG);

        // Задаем макет для отображения уведомления
        View layout = getLayoutInflater().inflate(R.layout.custom_layout, (ViewGroup) findViewById(R.id.toast_layout));
        notification.setView(layout);

        // Отображаем уведомление
        notification.show();

    }
}