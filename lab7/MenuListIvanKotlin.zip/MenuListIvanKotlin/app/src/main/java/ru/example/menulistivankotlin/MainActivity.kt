package ru.example.menulistivankotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView


class MainActivity : AppCompatActivity() {
    private lateinit var textView: TextView // объявление переменной
    private lateinit var imageView: ImageView // объявление переменной
    private lateinit var button: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textView = findViewById(R.id.textView)
        imageView = findViewById(R.id.imageView)
        button = findViewById(R.id.button)

        val popupMenu = PopupMenu(this, imageView)
        popupMenu.inflate(R.menu.popupmenu)

        imageView.setOnClickListener{
            popupMenu.show()
        }

        button.setOnClickListener{
            showPopupMenu(button)
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.action_lang1 -> {
                textView.text = "Вы выбрали Java!"
                return true
            }
            R.id.action_lang2 -> {
                textView.text = "Вы выбрали Kotlin!"
                return true
            }
            R.id.action_lang3 -> {
                textView.text = "Вы выбрали Python!"
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showPopupMenu(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.inflate(R.menu.popupmenu)
        popupMenu.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.menu1 -> {
                    textView.text = "Вы выбрали PopupMenu 1"
                    true
                }
                R.id.menu2 -> {
                    textView.text = "Вы выбрали PopupMenu 2"
                    true
                }
                R.id.menu3 -> {
                    textView.text = "Вы выбрали PopupMenu 3"
                    true
                }
                else -> false
            }
        }
        popupMenu.show()
    }

}