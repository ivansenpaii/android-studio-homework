package com.example.swapscreenivanjava;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button aboutButton = findViewById(R.id.aboutButton);

        Button secondButton = findViewById(R.id.secondButton);

        aboutButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });
        /*Перееход на доп. активность*/
        secondButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                                Intent intent = new Intent(MainActivity.this, ThridActivity.class);
                startActivity(intent);
            }
        });/*Перееход на доп. активность*/

        secondButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                EditText userEditText = (EditText) findViewById(R.id.editTextUser);
                EditText giftEditText = (EditText) findViewById(R.id.editTextGift);
                EditText giftFromText = (EditText) findViewById(R.id.giftFromText);

                Intent intent = new Intent(MainActivity.this, ThridActivity.class);
                // в ключ username пишем текст из первого текстового поля
                intent.putExtra("username", userEditText.getText().toString());
                // в ключ gift пишем текст из второго текстового поля
                intent.putExtra("gift", giftEditText.getText().toString());
                // МОЙ КОД
                intent.putExtra("from", giftFromText.getText().toString());

                startActivity(intent);
        }
        });

    }


}