package com.example.swapscreenivanjava;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

public class ThridActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thrid);

        String user = "Животное";
        String gift = "дырку от бублика";
        String from = "абоба";


        user = getIntent().getExtras().getString("username");
        gift = getIntent().getExtras().getString("gift");
        from = getIntent().getExtras().getString("from");


        TextView infoTextView = (TextView)findViewById(R.id.textViewInfo);
        infoTextView.setText(user + " , вам передали " + gift + " От: " + from);


    }
}