package com.example.sherlockivan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    static final private int CHOOSE_THIEF = 0;


    //TODO рабочий метод для первой реализации

/*        public void onClick(View v) {
        Intent questionIntent = new Intent(MainActivity.this,
                SecondActivity.class);
        startActivityForResult(questionIntent, CHOOSE_THIEF);
    }*/

    public static final String ACTION_SECOND_ACTIVITY = "ru.Ivan4ik.testapplication.SecondActivity";

    //TODO рабочий метод для второй реализации
/*
    public void onClick(View view) {
        startActivityForResult(new Intent(ACTION_SECOND_ACTIVITY), CHOOSE_THIEF);
    }
*/


    //TODO рабочий метод для третей реализации
    public void onClick(View view) {
        try {
            // Полное название класса активности
            String activityName = "com.example.sherlockivan.SecondActivity";
            // получим объект Class
            Class<?> myClass = Class.forName(activityName);
            Intent intent = new Intent(this, myClass);
            startActivityForResult(intent, CHOOSE_THIEF);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }




    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        TextView infoTextView = (TextView) findViewById(R.id.textViewInfo);
        if (requestCode == CHOOSE_THIEF) {
            if (resultCode == RESULT_OK) {
                String thiefname =
                        data.getStringExtra(SecondActivity.THIEF);
                infoTextView.setText(thiefname);
            }else {
                infoTextView.setText(""); // стираем текст
            }
        }
    }

}