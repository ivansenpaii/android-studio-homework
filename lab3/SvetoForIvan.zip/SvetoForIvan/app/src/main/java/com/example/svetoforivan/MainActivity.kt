package com.example.svetoforivan

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.graphics.Color
import androidx.core.content.ContextCompat


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val red_button = findViewById<Button>(R.id.red_button)

        val yellow_button = findViewById<Button>(R.id.yellow_button)

        val green_button = findViewById<Button>(R.id.green_button)

        val HelloText = findViewById<TextView>(R.id.Hello)

        val root_layout = findViewById<View>(R.id.root_layout)

        /*Упростили до одной функции*/
        fun setButtonClickListener(button: Button, colorId: Int, textId: Int) {
            button.setOnClickListener {
                HelloText.setText(textId)
                root_layout.setBackgroundColor(ContextCompat.getColor(this, colorId))
            }
        }/*Упростили до одной функции*/

        setButtonClickListener(red_button, R.color.redColor, R.string.red)
        setButtonClickListener(yellow_button, R.color.yellowColor, R.string.yellow)
        setButtonClickListener(green_button, R.color.greenColor, R.string.green)

    }



}