package com.example.hellofriendktln

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView

import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var imageButton = findViewById(R.id.imageButton) as ImageButton
        var textView = findViewById(R.id.textView) as TextView
        var editText = findViewById(R.id.editText) as EditText

        imageButton.setOnClickListener {
            if (editText.text.isEmpty()) {
                textView.text = "Hello Friend";
            } else {
                textView.text = "Привет, " + editText.text
            }
        }
    }
}
