package com.example.counterjv;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button mStudentsCounterButton;
    private TextView mInfoTextView;
    private int mCount = 0;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mStudentsCounterButton = findViewById(R.id.StudentsCounterButton);
        mInfoTextView = findViewById(R.id.textView4);
        mStudentsCounterButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                mInfoTextView.setText("Я насчитал " + ++mCount + " студентов");
            }
        }
        );
    }
    public void onClick(View view)
    {
        mInfoTextView.setText("Hello Friend");
    }

}