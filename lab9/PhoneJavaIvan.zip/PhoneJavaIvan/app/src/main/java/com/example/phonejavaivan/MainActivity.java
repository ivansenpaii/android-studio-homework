package com.example.phonejavaivan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView number1 = findViewById(R.id.number1);
        TextView number2 = findViewById(R.id.number2);
        TextView number3 = findViewById(R.id.number3);
        TextView number4 = findViewById(R.id.number4);

        setTextViewClickListener(number1, R.string.number79963807895);
        setTextViewClickListener(number2, R.string.number79963807896);
        setTextViewClickListener(number3, R.string.number79963807897);
        setTextViewClickListener(number4, R.string.number79963807898);
    }

    private void setTextViewClickListener(TextView textView, final int numberResId) {
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = getString(numberResId);
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null));
                startActivity(intent);
            }
        });
    }
}
