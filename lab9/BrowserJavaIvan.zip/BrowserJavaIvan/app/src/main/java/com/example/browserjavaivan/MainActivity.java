package com.example.browserjavaivan;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView link1 = findViewById(R.id.link1);
        TextView link2 = findViewById(R.id.link2);
        TextView link3 = findViewById(R.id.link3);

        link1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLinkDialog(getString(R.string.link1));
            }
        });

        link2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLinkDialog(getString(R.string.link2));
            }
        });

        link3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLinkDialog(getString(R.string.link3));
            }
        });
    }

    private void openLinkDialog(final String url) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Выберите действие")
                .setMessage("Открыть ссылку в браузере или в WebViewActivity?")
                .setPositiveButton("Браузер", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openLinkInBrowser(url);
                    }
                })
                .setNegativeButton("WebViewActivity", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openLinkInWebView(url);
                    }
                })
                .show();
    }

    private void openLinkInBrowser(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

    private void openLinkInWebView(String url) {
        Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
        intent.putExtra("url", url);
        startActivity(intent);
    }
}