package com.example.internetcheckjava;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private ConnectivityManager connectivityManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        updateConnectionStatus();
    }

    private void updateConnectionStatus() {
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();

        if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
            imageView.setImageResource(R.drawable.yes);
            showToast("Есть подключение к Интернету");
        } else {
            imageView.setImageResource(R.drawable.no);
            showToast("Нет подключения к Интернету");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, "Статус подключения: " + message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateConnectionStatus();
    }
}
