package com.example.mailformjavaivan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText mToEditText;
    private EditText mSubjectEditText;
    private EditText mMessageEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mToEditText = findViewById(R.id.mail);
        mSubjectEditText = findViewById(R.id.theme);
        mMessageEditText = findViewById(R.id.message);

        Button sendButton = findViewById(R.id.send);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendEmail();
            }
        });

        Button clearButton = findViewById(R.id.clear);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearFields();
            }
        });
    }

    private void sendEmail() {
        String to = mToEditText.getText().toString();
        String subject = mSubjectEditText.getText().toString();
        String message = mMessageEditText.getText().toString();

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse(
                "mailto:" + to +
                        "?subject=" + Uri.encode(subject) +
                        "&body=" + Uri.encode(message)));
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, message);
        startActivity(Intent.createChooser(emailIntent, "Send Email"));
    }


    private void clearFields() {
        mToEditText.setText("");
        mSubjectEditText.setText("");
        mMessageEditText.setText("");
    }
}


