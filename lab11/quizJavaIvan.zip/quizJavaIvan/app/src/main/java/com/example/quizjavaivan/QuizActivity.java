package com.example.quizjavaivan;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class QuizActivity extends AppCompatActivity {

    private Button answer1Button;
    private Button answer2Button;
    private Button answer3Button;
    private Button answer4Button;

    private String selectedCountry;

    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        // Инициализация базы данных
        copyDatabaseFromAssets();
        database = openOrCreateDatabase("smol.db", MODE_PRIVATE, null);


        TextView questionTextView = findViewById(R.id.questionTextView);
        answer1Button = findViewById(R.id.answer1Button);
        answer2Button = findViewById(R.id.answer2Button);
        answer3Button = findViewById(R.id.answer3Button);

        selectedCountry = getIntent().getStringExtra("country");

        // Инициализация базы данных
        database = openOrCreateDatabase("smol.db", MODE_PRIVATE, null);

        // Получение вопроса и ответов из базы данных
        String question = getQuestionFromDB();
        String[] answers = getAnswersFromDB();

        // Установка вопроса и ответов на экране
        questionTextView.setText(question);
        answer1Button.setText(answers[0]);
        answer2Button.setText(answers[1]);
        answer3Button.setText(answers[2]);

        // Назначение слушателей для кнопок
        answer1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(answer1Button.getText().toString());
            }
        });

        answer2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(answer2Button.getText().toString());
            }
        });

        answer3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(answer3Button.getText().toString());
            }
        });
    }

    private String getQuestionFromDB() {
        String question = "";
        String query = "SELECT QuestionText FROM Questions WHERE QuestionID = " + getQuestionID();
        Cursor cursor = database.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            question = cursor.getString(0);
        }
        cursor.close();
        return question;
    }

    private String[] getAnswersFromDB() {
        String[] answers = new String[4];
        String query = "SELECT AnswerText FROM Answers WHERE QuestionID = " + getQuestionID();
        Cursor cursor = database.rawQuery(query, null);
        int i = 0;
        while (cursor.moveToNext()) {
            answers[i] = cursor.getString(0);
            i++;
        }
        cursor.close();
        return answers;
    }

    private int getQuestionID() {
        int questionID = 0;
        if (selectedCountry.equals("Россия")) {
            questionID = 1;
        } else if (selectedCountry.equals("Франция")) {
            questionID = 2;
        } else if (selectedCountry.equals("Великобритания")) {
            questionID = 3;
        } else if (selectedCountry.equals("Италия")) {
            questionID = 4;
        } else if (selectedCountry.equals("Япония")) {
            questionID = 5;
        }
        return questionID;
    }

    private void checkAnswer(String selectedAnswer) {
        String query = "SELECT CorrectAnswerID FROM Answers WHERE QuestionID = " + getQuestionID();
        Cursor cursor = database.rawQuery(query, null);
        int correctAnswerID = 0;
        if (cursor.moveToFirst()) {
            correctAnswerID = cursor.getInt(0);
        }
        cursor.close();

        // Получение текста правильного ответа на основе correctAnswerID
        String correctAnswer = getAnswerText(correctAnswerID);

        if (selectedAnswer.equals(correctAnswer)) {
            Toast.makeText(this, "Вы выбрали правильный ответ", Toast.LENGTH_SHORT).show();
            // Изменить состояние кнопок
            answer1Button.setBackgroundColor(Color.GREEN);
            answer2Button.setBackgroundColor(Color.RED);
            answer3Button.setBackgroundColor(Color.RED);
        } else {
            Toast.makeText(this, "Вы выбрали неправильный ответ", Toast.LENGTH_SHORT).show();
            // Изменить состояние кнопки с правильным ответом
            if (correctAnswerID == 1) {
                answer1Button.setBackgroundColor(Color.GREEN);
            } else if (correctAnswerID == 2) {
                answer2Button.setBackgroundColor(Color.GREEN);
            } else if (correctAnswerID == 3) {
                answer3Button.setBackgroundColor(Color.GREEN);
            }
            // Изменить состояние остальных кнопок
            if (!answer1Button.getText().toString().equals(selectedAnswer)) {
                answer1Button.setBackgroundColor(Color.RED);
            }
            if (!answer2Button.getText().toString().equals(selectedAnswer)) {
                answer2Button.setBackgroundColor(Color.RED);
            }
            if (!answer3Button.getText().toString().equals(selectedAnswer)) {
                answer3Button.setBackgroundColor(Color.RED);
            }
        }
    }

    private String getAnswerText(int answerID) {
        String answerText = "";
        String query = "SELECT AnswerText FROM Answers WHERE QuestionID = " + getQuestionID() + " AND AnswerID = " + answerID;
        Cursor cursor = database.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            answerText = cursor.getString(0);
        }
        cursor.close();
        return answerText;
    }

    private String getCorrectAnswer() {
        String correctAnswer = "";
        String query = "SELECT AnswerText FROM Answers WHERE QuestionID = " + getQuestionID() + " AND AnswerID = (SELECT CorrectAnswerID FROM Answers WHERE QuestionID = " + getQuestionID() + ")";
        Cursor cursor = database.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            correctAnswer = cursor.getString(0);
        }
        cursor.close();
        return correctAnswer;
    }

    private void copyDatabaseFromAssets() {
        try {
            InputStream inputStream = getAssets().open("smol.db");
            String outFileName = getDatabasePath("smol.db").getPath();
            OutputStream outputStream = new FileOutputStream(outFileName);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.flush();
            outputStream.close();
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}