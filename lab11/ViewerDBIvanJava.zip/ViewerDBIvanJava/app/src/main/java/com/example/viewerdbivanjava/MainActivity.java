package com.example.viewerdbivanjava;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnAnimals = findViewById(R.id.btnAnimals);
        Button btnFriends = findViewById(R.id.btnFriends);
        Button btnFruits = findViewById(R.id.btnFruits);

        btnAnimals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTableActivity("animals");
            }
        });

        btnFriends.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTableActivity("friends");
            }
        });

        btnFruits.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTableActivity("fruits");
            }
        });
    }

    private void openTableActivity(String tableName) {
        Intent intent = new Intent(this, TableActivity.class);
        intent.putExtra("tableName", tableName);
        startActivity(intent);
    }
}
