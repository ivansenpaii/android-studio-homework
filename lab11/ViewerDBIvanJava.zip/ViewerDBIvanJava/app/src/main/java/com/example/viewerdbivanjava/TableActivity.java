package com.example.viewerdbivanjava;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class TableActivity extends AppCompatActivity {

    private ListView listView;
    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);

        listView = findViewById(R.id.listView);

        String tableName = getIntent().getStringExtra("tableName");
        database = openDatabase();
        displayTableContents(tableName);
    }

    private SQLiteDatabase openDatabase() {
        try {
            File dbFile = getDatabasePath("smol.db");
            if (!dbFile.exists()) {
                InputStream inputStream = getAssets().open("smol.db");
                OutputStream outputStream = new FileOutputStream(dbFile);

                byte[] buffer = new byte[1024];
                int length;
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                }

                outputStream.flush();
                outputStream.close();
                inputStream.close();
            }

            return SQLiteDatabase.openDatabase(dbFile.getPath(), null, SQLiteDatabase.OPEN_READWRITE);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }


    private void displayTableContents(String tableName) {
        List<String> items = new ArrayList<>();

        Cursor cursor = database.rawQuery("SELECT * FROM " + tableName, null);
        int columnsCount = cursor.getColumnCount();

        // Добавляем названия колонок к списку items
        StringBuilder columnNamesBuilder = new StringBuilder();
        for (int i = 0; i < columnsCount; i++) {
            columnNamesBuilder.append(cursor.getColumnName(i)).append(" ");
        }
        items.add(columnNamesBuilder.toString());

        while (cursor.moveToNext()) {
            StringBuilder rowBuilder = new StringBuilder();
            for (int i = 0; i < columnsCount; i++) {
                rowBuilder.append(cursor.getString(i)).append(" ");
            }
            items.add(rowBuilder.toString());
        }

        cursor.close();
        database.close();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);
    }

}
