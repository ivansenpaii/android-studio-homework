package com.example.orientationjv;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
//Создадим метод onClick
    public void onClick(View view) {
        TextView textView = findViewById(R.id.textView);

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
// Вывод результата в консоль будем производить с помощью System.out.println
            textView.setText("Портретная ориентация");
            System.out.println("Портретная ориентация");
        }
        else if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            textView.setText("Альбомная ориентация");
            System.out.println("Альбомная ориентация");
        }
        else System.out.println ("");
    }
}